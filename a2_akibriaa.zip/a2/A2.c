#define _POSIX_C_SOURCE 200809L
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

int fds[10][2];
char files[256][256];
pid_t pids[10];
int n = 0;
int n2;
int **res;

void getHist(char *file, int i)
{
    FILE *fp = fopen(file, "r");
    if (fp == NULL)
    {
        res[i][0] = -1;
        return;
    }
    char c = fgetc(fp);
    while (c != EOF)
    {
        if (c >= 65 && c <= 90)
        {
            res[i][c + 32 - 97] = res[i][c + 32 - 97] + 1;
        }
        else if (c >= 97 && c <= 122)
        {
            res[i][c - 97] = res[i][c - 97] + 1;
        }
        c = fgetc(fp);
    }
    fclose(fp);
}

void handler(int signal, siginfo_t *info, void *context)
{
    n--;
    pid_t sender_pid = info->si_pid;
    if (signal == SIGCHLD)
    {
        printf("Received SIGCHILD from process %d\n", sender_pid);
        int status;
        waitpid(-1, &status, WNOHANG);
        printf("Child exited with status=%d\n", WEXITSTATUS(status));
        if (status == 0)
        {
            int thisProc = 0;
            for (int i = 0; i < n2; i++)
            {
                if (pids[i] == sender_pid)
                {
                    thisProc = i;
                    break;
                }
            }
            close(fds[thisProc][1]);
            int readbuffer[26];
            read(fds[thisProc][0], readbuffer, sizeof(int) * 26);
            close(fds[thisProc][0]);
            char small[256];
            char big[4096];
            big[0] = '\0';
            for (int k = 0; k < 26; k++)
            {
                sprintf(small, "%c %d\n", k + 97, readbuffer[k]);
                strcat(big, small);
            }
            sprintf(small, "file%d.hist", sender_pid);
            int fd = open(small, O_WRONLY | O_CREAT | O_TRUNC, 0644);
            write(fd, big, strlen(big));
            close(fd);
        }
        else
        {
            printf("abnormal child termination %d\n",sender_pid);
        }
    }
}

int main(int argc, char *argv[])
{
    int i;
    n = argc - 1;
    n2 = n;
    if (n < 1)
    {
        printf("need args\n");
        return 1;
    }

    struct sigaction sa;
    sa.sa_flags = SA_SIGINFO;
    sa.sa_sigaction = handler;
    sigemptyset(&sa.sa_mask);
    sigaddset(&(sa.sa_mask), SIGCHLD);
    sigaction(SIGCHLD, &sa, NULL);
    res = malloc(sizeof(int *) * n);
    for (int i = 0; i < n; i++)
    {
        strcpy(files[i], argv[i + 1]);
        res[i] = calloc(26, sizeof(int));
        pipe(fds[i]);
    }

    for (i = 0; i < n; i++)
    {

        if ((pids[i] = fork()) < 0)
        {
            perror("fork");
            abort();
        }
        else if (pids[i] == 0)
        {
            if (strcmp(files[i], "SIG") != 0)
            {
                getHist(files[i], i);
                if (res[i][0] == -1)
                {
                    fprintf(stdout,"Invalid file\n");
                    exit(1);
                }
                close(fds[i][0]);
                write(fds[i][1], res[i], sizeof(int) * 27);
                close(fds[i][1]);
                free(res);
                sleep(10 + 2 * i);
                exit(0);
            }else{
                fprintf(stdout,"interrupting %d\n",getpid());
                kill(getpid(),SIGINT);
            }
        }
    }
    while (n > 0)
        ;
    for (int i = 0; i < n2; i++)
    {
        free(res[i]);
    }
    free(res);
    return 0;
}
